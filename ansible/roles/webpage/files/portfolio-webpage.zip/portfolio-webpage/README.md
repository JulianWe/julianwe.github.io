# Portfolio Webpage

A Pen created on CodePen.

Original URL: [https://codepen.io/leonam-silva-de-souza/pen/XJrwQOJ](https://codepen.io/leonam-silva-de-souza/pen/XJrwQOJ).

Source: Cryptical Coder  Main Part (https://www.youtube.com/watch?v=zJE-ze4TfXc) + Javascript Part (https://www.youtube.com/watch?v=DmiVBbNLzo8)